
# Farm Waste -> Fertilizer Advisor (Streamlit)

This is a single-file Streamlit application that helps convert farm/food/green waste into fertilizer recommendations.

## Features
- Evaluate available waste: estimate dry mass and N/P/K content from provided fresh masses.
- Design fertilizer for area: estimate tons of a primary waste required to meet crop N requirements per hectare.
- Compost/method suggestions, downloadable CSV and PDF reports.

## Run locally
1. Create a Python virtual environment (recommended):
   ```bash
   python -m venv venv
   source venv/bin/activate   # on Windows: venv\Scripts\activate
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run Streamlit:
   ```bash
   streamlit run app.py
   ```

## Files
- `app.py` - main Streamlit app
- `requirements.txt` - Python dependencies
- `sample_db.json` - sample waste and crop DB (editable)
- `README.md` - this file

## Notes
- The app uses N as the limiting nutrient for design calculations. You can extend the logic to perform linear mixing optimizations or include nutrient loss factors during composting.
- For production, consider adding unit tests, a proper database, and security/hardening for deployment.
