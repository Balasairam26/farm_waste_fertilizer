"""
Farm Waste -> Fertilizer Advisor (Streamlit app)
Single-file Streamlit application.

Features:
- Two modes:
  1) Evaluate available waste (user provides wastes + quantities)
  2) Design fertilizer for area (calculate required tons of waste to meet crop needs)
- Database of waste nutrient percentages (N, P, K) and crop nutrient requirements per hectare (kg/ha)
- Composting method suggestions, durations
- Summary tables, bar chart, downloadable CSV and simple PDF report
"""

import streamlit as st
import pandas as pd
import numpy as np
import io
import matplotlib.pyplot as plt
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from datetime import datetime

st.set_page_config(page_title="Farm Waste → Fertilizer Advisor", layout="wide")

# -------------------------
# Sample databases (editable)
# -------------------------
# Nutrient percentages are in percent by weight (dry weight)
WASTE_DB = {
    "Cow Dung": {"N": 0.5, "P": 0.25, "K": 0.5, "typical_moisture_pct": 70, "notes": "Good bulk organic matter"},
    "Poultry Manure": {"N": 2.5, "P": 1.5, "K": 1.0, "typical_moisture_pct": 40, "notes": "High N — handle carefully"},
    "Sheep/Goat Manure": {"N": 1.2, "P": 0.6, "K": 0.5, "typical_moisture_pct": 60, "notes": ""},
    "Rice Straw": {"N": 0.4, "P": 0.06, "K": 0.35, "typical_moisture_pct": 15, "notes": "High C:N — needs green nitrogenous input"},
    "Banana Peel (dry)": {"N": 1.0, "P": 0.6, "K": 2.5, "typical_moisture_pct": 10, "notes": "Very high K"},
    "Green Crop Waste": {"N": 1.5, "P": 0.2, "K": 0.8, "typical_moisture_pct": 70, "notes": "Good N source when fresh"},
    "Food Waste (mixed)": {"N": 1.2, "P": 0.5, "K": 0.6, "typical_moisture_pct": 60, "notes": "Varies widely"},
}

# Crop nutrient requirement per hectare (kg/ha) typical values (editable)
CROP_DB = {
    "Wheat": {"N": 120, "P": 40, "K": 60},
    "Rice": {"N": 150, "P": 50, "K": 60},
    "Maize": {"N": 200, "P": 60, "K": 80},
    "Vegetables (mixed)": {"N": 160, "P": 60, "K": 120},
    "Sugarcane": {"N": 250, "P": 70, "K": 300},
    "Groundnut": {"N": 50, "P": 40, "K": 60},
}

# Composting methods suggestions (simple heuristics)
COMPOST_METHODS = {
    "Vermicomposting": {"suitable_for": ["Cow Dung", "Green Crop Waste", "Food Waste (mixed)", "Sheep/Goat Manure"],
                        "duration_days": 45, "notes": "Good for high N and soft wastes; produces rich humus"},
    "Windrow Composting": {"suitable_for": list(WASTE_DB.keys()), "duration_days": 60, "notes": "Good for bulky/field wastes"},
    "Anaerobic Digestion (biogas)": {"suitable_for": ["Cow Dung", "Poultry Manure", "Food Waste (mixed)"], "duration_days": 30, "notes": "Produces biogas and slurry"},
    "Direct Mulching": {"suitable_for": ["Rice Straw", "Green Crop Waste"], "duration_days": 0, "notes": "Used as mulch; no composting needed"},
    "Vermicompost + Passive Curing": {"suitable_for": list(WASTE_DB.keys()), "duration_days": 75, "notes": "Vermicompost then cure for stability"},
}

# -------------------------
# Helper functions
# -------------------------
def nutrient_per_ton_from_pct(pct):
    return pct * 10.0

def solid_mass_from_fresh_mass(fresh_kg, moisture_pct):
    dry_fraction = max(0.0, 1.0 - moisture_pct / 100.0)
    return fresh_kg * dry_fraction

def summarize_nutrients(selected_wastes):
    total_dry = 0.0
    total_N = 0.0
    total_P = 0.0
    total_K = 0.0
    breakdown = []
    for wname, fresh_kg in selected_wastes:
        meta = WASTE_DB.get(wname)
        if not meta:
            continue
        dry_kg = solid_mass_from_fresh_mass(fresh_kg, meta.get("typical_moisture_pct", 50))
        N_kg = dry_kg * (meta["N"] / 100.0)
        P_kg = dry_kg * (meta["P"] / 100.0)
        K_kg = dry_kg * (meta["K"] / 100.0)
        total_dry += dry_kg
        total_N += N_kg
        total_P += P_kg
        total_K += K_kg
        breakdown.append({
            "waste": wname,
            "fresh_kg": fresh_kg,
            "dry_kg": round(dry_kg, 2),
            "N_kg": round(N_kg, 3),
            "P_kg": round(P_kg, 3),
            "K_kg": round(K_kg, 3),
        })
    return {
        "total_dry_kg": round(total_dry, 2),
        "total_N_kg": round(total_N, 3),
        "total_P_kg": round(total_P, 3),
        "total_K_kg": round(total_K, 3),
        "breakdown": breakdown
    }

def suggest_compost_methods(waste_names):
    suggestions = []
    for method, meta in COMPOST_METHODS.items():
        if any(w in meta["suitable_for"] for w in waste_names):
            suggestions.append({"method": method, "duration_days": meta["duration_days"], "notes": meta["notes"]})
    suggestions.sort(key=lambda x: x["duration_days"])
    return suggestions

def design_for_area(primary_waste, area_ha, crop_name):
    if crop_name not in CROP_DB:
        raise ValueError("Unknown crop")
    crop_req = CROP_DB[crop_name]
    req_N = crop_req["N"] * area_ha
    req_P = crop_req["P"] * area_ha
    req_K = crop_req["K"] * area_ha
    meta = WASTE_DB.get(primary_waste)
    if not meta:
        raise ValueError("Unknown waste")
    N_per_ton = nutrient_per_ton_from_pct(meta["N"])
    P_per_ton = nutrient_per_ton_from_pct(meta["P"])
    K_per_ton = nutrient_per_ton_from_pct(meta["K"])
    if N_per_ton <= 0:
        tons_for_N = float('inf')
    else:
        tons_for_N = req_N / N_per_ton
    delivered_N = N_per_ton * tons_for_N
    delivered_P = P_per_ton * tons_for_N
    delivered_K = K_per_ton * tons_for_N
    deficit_P = max(0.0, req_P - delivered_P)
    deficit_K = max(0.0, req_K - delivered_K)
    moisture = meta.get("typical_moisture_pct", 50) / 100.0
    fresh_per_ton = 1000.0 / (1 - moisture) if (1 - moisture) > 0 else 1000.0
    fresh_needed_kg = tons_for_N * fresh_per_ton * 1000 / 1000.0
    fresh_needed_tons = fresh_needed_kg / 1000.0
    return {
        "area_ha": area_ha,
        "crop": crop_name,
        "req_N_kg": req_N,
        "req_P_kg": req_P,
        "req_K_kg": req_K,
        "waste": primary_waste,
        "N_per_ton_kg": round(N_per_ton, 2),
        "P_per_ton_kg": round(P_per_ton, 2),
        "K_per_ton_kg": round(K_per_ton, 2),
        "tons_required": round(tons_for_N, 3),
        "fresh_needed_tons": round(fresh_needed_tons, 3),
        "delivered_N_kg": round(delivered_N, 2),
        "delivered_P_kg": round(delivered_P, 2),
        "delivered_K_kg": round(delivered_K, 2),
        "deficit_P_kg": round(deficit_P, 2),
        "deficit_K_kg": round(deficit_K, 2),
    }

def create_pdf_report(summary: dict, mode: str):
    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4
    margin = 40
    y = height - margin
    c.setFont("Helvetica-Bold", 14)
    c.drawString(margin, y, "Farm Waste → Fertilizer Advisor Report")
    c.setFont("Helvetica", 10)
    y -= 20
    c.drawString(margin, y, f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    y -= 30
    c.setFont("Helvetica-Bold", 12)
    c.drawString(margin, y, f"Mode: {mode.title()}")
    y -= 20
    c.setFont("Helvetica", 10)
    if mode == "evaluate":
        c.drawString(margin, y, f"Total dry mass (kg): {summary['total_dry_kg']}")
        y -= 15
        c.drawString(margin, y, f"Total N (kg): {summary['total_N_kg']}, P (kg): {summary['total_P_kg']}, K (kg): {summary['total_K_kg']}")
        y -= 20
        c.drawString(margin, y, "Breakdown:")
        y -= 15
        for b in summary['breakdown']:
            if y < 120:
                c.showPage()
                y = height - margin
            c.drawString(margin, y, f"{b['waste']}: fresh={b['fresh_kg']}kg, dry={b['dry_kg']}kg, N={b['N_kg']}kg, P={b['P_kg']}kg, K={b['K_kg']}kg")
            y -= 12
    else:
        c.drawString(margin, y, f"Crop: {summary['crop']}, Area (ha): {summary['area_ha']}")
        y -= 15
        c.drawString(margin, y, f"Primary waste: {summary['waste']}")
        y -= 15
        c.drawString(margin, y, f"Tons required (compost/dry equiv): {summary['tons_required']}")
        y -= 15
        c.drawString(margin, y, f"Expected delivered (kg): N={summary['delivered_N_kg']}, P={summary['delivered_P_kg']}, K={summary['delivered_K_kg']}")
        y -= 15
        c.drawString(margin, y, f"Deficits (kg): P={summary['deficit_P_kg']}, K={summary['deficit_K_kg']}")
        y -= 15
    c.showPage()
    c.save()
    buffer.seek(0)
    return buffer.read()

st.title("🌾 Farm Waste → Fertilizer Advisor")
st.markdown("""
This app helps convert farm/food/green waste into fertilizer recommendations:
- **Evaluate** available waste for nutrient content and coverage, or
- **Design** how much waste/compost is needed to meet crop nutrient needs (per hectare).
""")
st.sidebar.header("Database & Settings")
if st.sidebar.checkbox("Show waste DB (sample)", value=False):
    df_w = pd.DataFrame.from_dict(WASTE_DB, orient='index')
    st.sidebar.dataframe(df_w)
if st.sidebar.checkbox("Show crop DB (sample)", value=False):
    df_c = pd.DataFrame.from_dict(CROP_DB, orient='index')
    st.sidebar.dataframe(df_c)
mode = st.radio("Choose mode", ["Evaluate available waste", "Design fertilizer for area"]) 
if mode == "Evaluate available waste":
    st.header("Evaluate available waste")
    st.markdown("Enter the wastes you have and their **fresh mass (kg)**. The app estimates dry mass and nutrient content.")
    with st.form("waste_input_form"):
        rows = st.number_input("How many different waste items to enter?", min_value=1, max_value=6, value=2, step=1)
        entries = []
        for i in range(rows):
            col1, col2 = st.columns([2,1])
            with col1:
                w = st.selectbox(f"Waste #{i+1}", options=list(WASTE_DB.keys()), key=f"waste_{i}")
            with col2:
                q = st.number_input(f"Fresh mass (kg) #{i+1}", min_value=0.0, value=0.0, step=0.5, key=f"qty_{i}")
            entries.append((w, q))
        submitted = st.form_submit_button("Calculate")
    if submitted:
        selected = [(w, q) for (w, q) in entries if q > 0]
        if not selected:
            st.warning("Please enter at least one waste with quantity > 0 kg.")
        else:
            summary = summarize_nutrients(selected)
            st.subheader("Nutrient Summary (after estimated drying)")
            st.metric("Total dry mass (kg)", summary["total_dry_kg"]) 
            colA, colB, colC = st.columns(3)
            colA.metric("Total N (kg)", summary["total_N_kg"]) 
            colB.metric("Total P (kg)", summary["total_P_kg"]) 
            colC.metric("Total K (kg)", summary["total_K_kg"]) 
            st.markdown("**Breakdown by waste**")
            df_break = pd.DataFrame(summary["breakdown"]) 
            st.dataframe(df_break)
            st.markdown("### Coverage estimate")
            crop_choice = st.selectbox("Select crop to estimate coverage", list(CROP_DB.keys()))
            crop_req = CROP_DB[crop_choice]
            area_by_N = summary["total_N_kg"] / crop_req["N"] if crop_req["N"]>0 else 0.0
            area_by_P = summary["total_P_kg"] / crop_req["P"] if crop_req["P"]>0 else 0.0
            area_by_K = summary["total_K_kg"] / crop_req["K"] if crop_req["K"]>0 else 0.0
            st.write(f"Estimated area that can be fertilized (hectares) if used alone:")
            st.write(f"- By N: **{area_by_N:.3f} ha**")
            st.write(f"- By P: **{area_by_P:.3f} ha**")
            st.write(f"- By K: **{area_by_K:.3f} ha**")
            limiting = min(area_by_N, area_by_P, area_by_K)
            st.info(f"Overall limiting nutrient suggests ~ **{limiting:.3f} ha** could be fertilized fully (based on current nutrient balance).")
            waste_names = [w for w, _ in selected]
            methods = suggest_compost_methods(waste_names)
            st.markdown("### Composting / Processing Suggestions")
            for m in methods:
                st.write(f"- **{m['method']}** — ~{m['duration_days']} days. {m['notes']}")
            fig, ax = plt.subplots()
            ax.bar(["N", "P", "K"], [summary["total_N_kg"], summary["total_P_kg"], summary["total_K_kg"]])
            ax.set_ylabel("kg total")
            ax.set_title("Total nutrient content from provided wastes")
            st.pyplot(fig)
            csv_buf = io.StringIO()
            df_break.to_csv(csv_buf, index=False)
            st.download_button("Download breakdown CSV", csv_buf.getvalue().encode('utf-8'), file_name="waste_breakdown.csv", mime="text/csv")
            pdf_bytes = create_pdf_report(summary, mode="evaluate")
            st.download_button("Download PDF report", data=pdf_bytes, file_name="fertilizer_report_evaluate.pdf", mime="application/pdf")
else:
    st.header("Design fertilizer for area")
    st.markdown("Calculate how much waste (tons) of a chosen primary waste would be required to meet crop N needs. This uses *N as the primary limiting nutrient*. It then shows P/K delivered and deficits.")
    with st.form("design_form"):
        crop = st.selectbox("Crop", options=list(CROP_DB.keys()))
        area = st.number_input("Area (hectares)", min_value=0.01, value=1.0, step=0.1, format="%.2f")
        primary = st.selectbox("Primary waste to use for compost (choose one)", options=list(WASTE_DB.keys()))
        submitted2 = st.form_submit_button("Design fertilizer")
    if submitted2:
        try:
            design = design_for_area(primary, area, crop)
        except Exception as e:
            st.error(str(e))
            design = None
        if design:
            st.subheader("Design Results")
            st.write(f"Crop: **{design['crop']}** — Area: **{design['area_ha']} ha**")
            st.write(f"Tons (dry-equivalent) of **{design['waste']}** required: **{design['tons_required']} tons**")
            st.write(f"Approx. fresh tons needed (estimate): **{design['fresh_needed_tons']} tons** (depends on moisture)")
            st.write("Nutrients delivered (kg):")
            st.write(f"- N: {design['delivered_N_kg']} kg (req {design['req_N_kg']} kg)")
            st.write(f"- P: {design['delivered_P_kg']} kg (req {design['req_P_kg']} kg)")
            st.write(f"- K: {design['delivered_K_kg']} kg (req {design['req_K_kg']} kg)")
            if design['deficit_P_kg'] > 0 or design['deficit_K_kg'] > 0:
                st.warning(f"Deficit detected: P deficit {design['deficit_P_kg']} kg, K deficit {design['deficit_K_kg']} kg. Consider blending with a higher-P or higher-K waste (e.g., Banana Peel for K) or add mineral fertilizer (DAP/TSP/MOP).")
            else:
                st.success("This waste amount supplies N, P and K requirements (based on N-limited calculation).")
            if design['deficit_P_kg'] > 0 or design['deficit_K_kg'] > 0:
                st.markdown("### Quick blending suggestions (heuristic)")
                df_waste = pd.DataFrame.from_dict(WASTE_DB, orient='index')
                highest_P = df_waste['P'].idxmax()
                highest_K = df_waste['K'].idxmax()
                st.write(f"- For P: consider blending with **{highest_P}** (P%={WASTE_DB[highest_P]['P']}%)")
                st.write(f"- For K: consider blending with **{highest_K}** (K%={WASTE_DB[highest_K]['K']}%)")
                st.info("A practical approach: split target tons between the primary waste and a small fraction (10-30%) of a P/K-rich waste and recalc. This app can be extended to solve a constrained linear mix if needed.")
            methods = suggest_compost_methods([primary])
            st.markdown("### Compost/processing suggestions")
            for m in methods:
                st.write(f"- **{m['method']}** — ~{m['duration_days']} days. {m['notes']}")
            df_design = pd.DataFrame([{"crop": design['crop'], "area_ha": design['area_ha'], "primary_waste": design['waste'], "tons_required": design['tons_required'], "fresh_needed_tons": design['fresh_needed_tons'], "delivered_N_kg": design['delivered_N_kg'], "delivered_P_kg": design['delivered_P_kg'], "delivered_K_kg": design['delivered_K_kg'], "deficit_P_kg": design['deficit_P_kg'], "deficit_K_kg": design['deficit_K_kg'], }])
            st.dataframe(df_design.T)
            fig2, ax2 = plt.subplots()
            ax2.bar(["Required N", "Delivered N"], [design['req_N_kg'], design['delivered_N_kg']])
            ax2.bar(["Required P", "Delivered P"], [design['req_P_kg'], design['delivered_P_kg']])
            ax2.set_title("Required vs Delivered (kg)")
            st.pyplot(fig2)
            csv_buf = io.StringIO()
            df_design.to_csv(csv_buf, index=False)
            st.download_button("Download design CSV", csv_buf.getvalue().encode('utf-8'), file_name="fertilizer_design.csv", mime="text/csv")
            pdf_bytes = create_pdf_report(design, mode="design")
            st.download_button("Download PDF report", data=pdf_bytes, file_name="fertilizer_report_design.pdf", mime="application/pdf")

st.markdown("---")
st.markdown("Made with ❤️ — extend the waste & crop DB or request additional features like multi-waste mixing solver, IoT soil sensor integration, or machine learning-based yield prediction.")
